package com.bharathi.trainer;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;



import com.bharathi.commons.BoundingBox;
import com.bharathi.commons.PointXY;
import com.bharathi.commons.Trace;
import com.bharathi.commons.TraceGroup;
import com.bharathi.entity.ImageData;
import com.bharathi.preprocess.PrepocessorUtil;
import com.bharathi.utils.PenFileReader;

public class Trainer {
	
	static String inputDir;
	static String outputDir;
	static HashMap<String, TraceGroup> trainFileMap = new HashMap<String, TraceGroup>();
	static HashMap<String, int[]> bitmapSet = new HashMap<String, int[]>();
	static HashMap<String, ImageData> imageDataSet = new HashMap<String, ImageData>();
	static int count = 0;
	static int filecount = 0;
	static int walkcount = 0;
	static int c = 0;
	
	public static void main(String args[]){
		
		if(args.length != 2){
			System.err.println("format <input folder> <output folder>");
			System.exit(1);
		}
		else{
			inputDir = args[0];
			outputDir = args[1];
		}
		
		File[] files = new File(inputDir).listFiles();
		
		walkThroughDatasets(files);
		//plotTraceGroupToBitmap();
		drawAndSave();
		System.out.println("Total files trained " + count);
		System.out.println("Total files trained " + filecount);
		//convertToImageDataSetAndSave();
		
	}
	
	
	static String newFilename(String filepath) {
		File dir = new File(filepath);
		final String prefix = "L_";
		File [] files = dir.listFiles(new FilenameFilter() {
		    @Override
		    public boolean accept(File dir, String name) {
		        return name.startsWith(prefix);
		    }
		}); 
		Integer filenos[] = new Integer[files.length];
		int i=0;
		for(File file : files) {
			String name = file.getName();
			int no;
			try {
				no = Integer.parseInt(name.substring(name.lastIndexOf("_")+1));
			} catch(Exception e) {
				no = 0;
			}			
			filenos[i++] = no;
		}
		Arrays.sort(filenos);
		
		String newName;
		
		try {
			newName = ""+(filenos[filenos.length-1]+1);
		} catch (Exception e) {
			newName = "1";
		}
		newName = prefix + newName;
		return newName;
	}

	private static String getLetter(String key) {
		
		String[] arr = {"அ",  "ஆ", " இ", "ஈ", "உ", "ஊ", "எ", "ஏ", "ஐ", "ஒ", "ஓ", 	"ஃ", 	"க" , 	"ங", 	"ச", "ஞ","ட", "ண",
				"த", 	"ந", 	"ப", 	"ம",	"ய", 	"ர", "ல", "வ", "ழ","ள" , "ற" , "ன", "ஸ" ,  "ஷ", "ஜ", "ஹ","\u0B95\u0BC1","\u0BB5\u0BC2",
		"\u0BBE","\u0BBF","\u0BC0","\u0BC1","\u0BC2","\u0BC6","\u0BC7",	"\u0BC8"};  
		
		
		return arr[Integer.parseInt(key)];
	}

	private static void plotTraceGroupToBitmap() {
		
		for(Map.Entry<String, TraceGroup> entry : trainFileMap.entrySet()) {
			
			BoundingBox box = entry.getValue().getBoundingBox();
			int height = (int) (box.yMax - box.yMin);
			int width = (int) (box.xMax - box.xMin);
			System.out.println("The bounding box is " + box);
			int pix[][] = new int[width + 1][height + 1];
			for(Trace t : entry.getValue().getTraceList()){
				for(PointXY p : t.getTracePoints()){
					try{
						pix[(int)p.getX()][(int)p.getY()] = java.awt.Color.WHITE.getRGB();
					}
					catch(Exception e){
					System.out.println("The faulty point " + p);
					System.exit(1);
					}
				}
			}
			int pixel[];
			
			ArrayList<Integer> list = new ArrayList<Integer>();
			for(int i = 0; i < pix.length; ++i)
				for(int j = 0; j < pix[i].length; ++j)
					list.add(pix[i][j]);
			
			pixel = convertIntegers(list);
			String key = entry.getKey().split("t")[0];
			
			ImageData iData = new ImageData(pixel, width, height, getLetter(key));
			try {
				String fname = newFilename(outputDir);
				String path = outputDir.endsWith("/")? outputDir : outputDir+"/";
				iData.save(path + fname);
				count++;
			} catch (IOException e) {
				e.printStackTrace();
				System.exit(1);
			}
			walkcount++;
				
			
		}
		
	}
	public static void drawAndSave(){
	    BasicStroke stroke = new BasicStroke(6.0f, BasicStroke.CAP_ROUND,BasicStroke.JOIN_ROUND);
		for(Map.Entry<String, TraceGroup> entry : trainFileMap.entrySet()) {
			BoundingBox box = entry.getValue().getBoundingBox();
			int height = (int) (box.yMax - box.yMin);
			int width = (int) (box.xMax - box.xMin);
			BufferedImage bimage = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		    Graphics2D g2d = bimage.createGraphics();
		    g2d.setColor(Color.WHITE);
		    g2d.setStroke(stroke);
		    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, // Anti-alias!
		            RenderingHints.VALUE_ANTIALIAS_ON);
			for(Trace t : entry.getValue().getTraceList()){
				PointXY prev= t.getPointAt(0);
				for(PointXY p : t.getTracePoints()){
					Line2D line = new Line2D.Float(prev.getX(), prev.getY(), 
						p.getX(), p.getY());
					g2d.draw(line);
					prev = p;
				}
			}
			 int[] pixel = ((DataBufferInt) bimage.getRaster().getDataBuffer()).getData();
				String key = entry.getKey().split("t")[0];

			 ImageData iData = new ImageData(pixel, width, height, getLetter(key));
				try {
					String fname = newFilename(outputDir);
					String path = outputDir.endsWith("/")? outputDir : outputDir+"/";
					iData.save(path + fname);
					count++;
				} catch (IOException e) {
					e.printStackTrace();
					System.exit(1);
				}
		}
	}
	
	public static int[] convertIntegers(List<Integer> integers)
	{
	    int[] ret = new int[integers.size()];
	    Iterator<Integer> iterator = integers.iterator();
	    for (int i = 0; i < ret.length; i++)
	    {
	        ret[i] = iterator.next().intValue();
	    }
	    return ret;
	}



	private static  void walkThroughDatasets(File[] files) {
		
		for(File f : files){
			if (!(c < 20)) break; 
			if(f.isDirectory()){
				walkThroughDatasets(f.listFiles());
				++c;
			}
			else{
				String[] abstractName = f.getName().split("t");
				String trainingClassName = abstractName[0];
				if(Integer.parseInt(trainingClassName) < 12){
					System.out.println("File : " + f.getName());
					TraceGroup tg = 
							PrepocessorUtil.smoothenTraceGroup(PrepocessorUtil.removeDuplicatePoints(
							PenFileReader.readTraceGroupFromFile(f)), 7);
					tg.translateTo(0, 0);
					trainFileMap.put(f.getName() + f.getParentFile().getName(), tg);
				}
			}
		}
		
		/*int i = 1;
			for(File file : files){
				if (i == 10) break;
			if(file.isDirectory()){
				System.out.println("Reading the directory : " + file.getName() + ":");
				for(File f : file.listFiles()){
					String[] abstractName = f.getName().split("t");
					String trainingClassName = abstractName[0];
					
					if(Integer.parseInt(trainingClassName) <= 20) {
						filecount++;
						System.out.println("File : " + file.getName());
						TraceGroup tg = 
								PrepocessorUtil.smoothenTraceGroup(PrepocessorUtil.removeDuplicatePoints(
								PenFileReader.readTraceGroupFromFile(file)), 7);
						tg.translateTo(0, 0);
						trainFileMap.put(file.getName() + file.getParentFile().getName(), tg);
					}
				}
			}
			i++;
		}
	}*/
	
}
}

			