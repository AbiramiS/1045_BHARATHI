package com.bharathi.commons;

public class CaptureDevice {
	
	private float xDPI;
	private float yDPI;
	
	public float getXDPI() {
		
		return xDPI;
	}

	public float getYDPI() {
		
		return yDPI;
	}

	public void setxDPI(float xDPI) {
		this.xDPI = xDPI;
	}

	public void setyDPI(float yDPI) {
		this.yDPI = yDPI;
	}
	
}
