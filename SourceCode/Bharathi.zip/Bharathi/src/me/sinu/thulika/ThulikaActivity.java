
package me.sinu.thulika;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class ThulikaActivity extends Activity {	
	SeekBar delaySeeker;
	TextView delayView;
	View helpButton;
	View feedbackButton;
	private final String touchupDelayKey = "me.sinu.stupidpen.touchupDelay";
	private final String stupidpenPrefs = "me.sinu.stupidpen";
	private long delay;
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    	
        final SharedPreferences prefs = getSharedPreferences(stupidpenPrefs, Context.MODE_PRIVATE);
		delay = prefs.getLong(touchupDelayKey, 250);
		
    	delaySeeker = (SeekBar) findViewById(R.id.delaySeeker);
    	delayView = (TextView) findViewById(R.id.delayView);
    	
    	
    	delayView.setText(String.valueOf(delay));
    	delaySeeker.setProgress((int)delay/50);
    	delaySeeker.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				delayView.setText(String.valueOf(progress*50));		
				prefs.edit().putLong(touchupDelayKey, progress*50).commit();
			}
		});
    }
}