

package me.sinu.thulika.lang;

import com.bharathi.entity.Engine;

import me.sinu.thulika.lang.common.LatinLangProcessor;

public class TamilProcessor extends LatinLangProcessor{

	private final String engineName = "engines/tami";
	public TamilProcessor(Engine engine) {
		super(engine);
	}

	@Override
	public String getEngineName() {
		return engineName;
	}

	@Override
	public String getFontName() {
		return null;
	}

}
