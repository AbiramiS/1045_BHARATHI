
package me.sinu.thulika.lang.common;

import com.bharathi.entity.CharData;
import com.bharathi.entity.Engine;
import com.bharathi.entity.LanguageProcessor;

public abstract class LatinLangProcessor implements LanguageProcessor{

	Engine engine;
	
	public LatinLangProcessor(Engine engine) {
		this.engine = engine;
	}
			
	public String getStack() {
		return "";
	}
	
	public String[] process(String previous, CharData current) {
		return new String[] {current.getSymbol()};
	}		
}


